/**
 * Loading test dependencies
 */

const request = require('supertest')
const server = require('../../server');
const chai = require('chai');
const chaiHttp = require('chai-http');
chai.use(chaiHttp);


/**
 * Short hands for chai functions
 */

var expect = chai.expect;
var assert = chai.assert;
var should = chai.should();


describe.skip('GET /game/owned/', () => {

    let valid = '76561198272843849';
    let invalid = '7656119827284';

    it('With valid steamid', done => {
        chai.request(server).get(`/game/owned/${valid}`)
            .end((err, res) => {
                res.should.have.status(200);
                res.body.games[0].name.should.equal('LIMBO');
                done();
            })
    });

    it('With invalid steamid', done => {
        chai.request(server).get(`/game/owned/${invalid}`)
            .end((err, res) => {
                res.should.have.status(400);
                res.body.error.should.equal(`Invalid steamid provided: ${invalid}`);
                done();
            })
    });
});

describe.skip('GET /game/info/', () => {

    let valid = '252490';
    let invalid = '12kwqe3';

    it('With valid appid', done => {
        chai.request(server).get(`/game/info/${valid}`)
            .end(async(err, res) => {
                await res.should.have.status(200);
                await res.body.name.should.equal('Rust');
                done();
            });
    });

    it('With invalid appid', done => {
        chai.request(server).get(`/game/info/${invalid}`)
            .end((err, res) => {
                res.should.have.status(400);
                res.body.error.should.equal(`Invalid appid provided: ${invalid}`);
                done();
            })
    });
});