/**
 * Include all dependencies
 */

const axios = require('axios');
const format = require('../util/format');
const Game = require('../models/Game');
const validator = require('../util/validator');


/**
 * Retreives all owned games from user
 * 
 * @param {Object} params 
 */

module.exports.getOwnedGame = params => {
    return new Promise(async(resolve, reject) => {

        let steamid = params['steamid'];
        let ftp = params['ftp'] || '1';

        let validate = { 'steamid': steamid, }
        let invalid = validator.checkArgValidity(validate);
        if (invalid) return reject(`Invalid ${invalid} provided: ${validate[invalid]}`);

        let baseUrl = `${process.env.STEAM_ENDPOINT_URL}/game/owned/${steamid}&ftp=${ftp}`;

        const result = await axios.get(baseUrl)
            .then(res => res.data)
            .catch(err => reject(err));

        let count = result.response.game_count;
        let cumulativeTime = 0;

        var games = []

        if (count === undefined) return reject('This Steam user has no game: ' + steamid);

        for (var i = 0; i < count; i++) {
            let game = Game.constructOwnedModel(result.response.games[i]);
            cumulativeTime += game.playtime.total;
            games.push(game);
        }

        if (games) return resolve({
            total: count,
            playtime: {
                total: cumulativeTime,
                text: format.readableTime(cumulativeTime * 60 * 60)
            },
            games: games
        });
        else return reject('Game not found.');
    });
}


/**
 * Retreives all info from game
 * 
 * @param {Object} params 
 */

module.exports.getGameInfo = params => {
    return new Promise(async(resolve, reject) => {
        let appid = params['appid'];

        let validate = { 'appid': appid, }
        let invalid = validator.checkArgValidity(validate);
        if (invalid) return reject(`Invalid ${invalid} provided: ${validate[invalid]}`);

        let baseUrl = `${process.env.STEAM_ENDPOINT_URL}/game/info/${appid}`;

        const result = await axios.get(baseUrl)
            .then(res => res.data)
            .catch(err => reject(err))

        let game = null
        if (result) game = Game.constructModel(result);

        if (game) return resolve(game);
        else return reject('Game not found.');
    });
}


/**
 * Retreives recently played games by steamid
 * 
 * @param {String} steamid 
 */

module.exports.getRecentGames = steamid => {
    return new Promise(async(resolve, reject) => {

        let validate = { steamid }
        let invalid = validator.checkArgValidity(validate);
        if (invalid) return reject(`Invalid ${invalid} provided: ${validate[invalid]}`);

        let baseUrl = `${process.env.STEAM_ENDPOINT_URL}/game/recent/${steamid}`;

        let data = await axios.get(baseUrl)
            .then(res => res.data)
            .catch(err => reject(err))

        let count = data.total_count;
        if (count === undefined) return resolve('This Steam user has no recently played games: ' + steamid);
        
        var cumulativeTime = 0;
        let games = [];

        for (var i = 0; i < count; i++) {
            let game = Game.constructOwnedModel(data.games[i]);
            cumulativeTime += game.playtime.recent.total;
            games.push(game);
        }

        if (games) return resolve({
            total: count,
            playtime: {
                total: cumulativeTime,
                text: format.readableTime(cumulativeTime * 60 * 60)
            },
            games: games
        });
        else return reject('Games not found.');
    });
}