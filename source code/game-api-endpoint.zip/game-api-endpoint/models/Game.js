/**
 * Include all dependecies 
 */

const format = require('../util/format');

/**
 * Construct Game model from Steam json data
 * 
 * @param {Object} data 
 */

module.exports.constructOwnedModel = data => {
    let name = data.name || 'Unknown';
    let appid = data.appid || 0;
    let playtime = {
        total: Math.floor(data.playtime_forever / 60) || 0,
        text: format.readableTime(Math.floor(data.playtime_forever / 60) * 3600),
        recent: {
            total: Math.floor(data.playtime_2weeks / 60) || 0,
            text: format.readableTime(Math.floor(data.playtime_2weeks / 60) * 3600),
        }
    };
    let logo = `${process.env.GAME_LOGO_URL}/${appid}/${data.img_icon_url}.jpg` || null;
    let banner = `${process.env.GAME_BANNER_URL}/${appid}/capsule_184x69.jpg` || null;

    return { name, appid, playtime, logo, banner };
};

module.exports.constructModel = data => {

    let name = data.name || 'Unknown';
    let appid = data.steam_appid || 0;
    let banner = data.header_image;
    let background = data.background;
    let description = data.short_description || 'N/A';
    let publishers = data.publishers || 'N/A';
    let price_text = data.hasOwnProperty('price_overview') ? format.readablePrice(data.price_overview.final) : 'Free';
    let platforms = data.platforms;
    let likes = data.recommendations.total || 0;

    return { name, appid, banner, background, description, publishers, price_text, platforms, likes };
}