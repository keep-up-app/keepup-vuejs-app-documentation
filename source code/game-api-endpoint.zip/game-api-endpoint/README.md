# game-api-endpoint
Handles all game request from front-end to be redirected to steam-api-endpoint
