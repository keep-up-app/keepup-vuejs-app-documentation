/**
 * Include all dependencies
 */

const gameController = require('../controllers/GameController');
const express = require('express');
const router = express.Router();

module.exports = router;


/**
 * Gets all owned game from user.
 * URI: game/owned
 */

router.get('/owned/:steamid', async(req, res) => {

    let data = await gameController.getOwnedGame({
        steamid: req.params.steamid,
        ftp: req.params.ftp
    }).catch(err => res.status(400).json({ error: err }));

    res.send(data);
});


/**
 * Gets game info from appid
 * URI: game/info
 */

router.get('/info/:appid', async(req, res) => {

    let data = await gameController.getGameInfo({
        appid: req.params.appid
    }).catch(err => res.status(400).json({ error: err }));

    res.send(data);
});


/**
 * Gets recently played games
 * URI: game/recent
 */

router.get('/recent/:steamid', async(req, res) => {

    let data = await gameController.getRecentGames(req.params.steamid)
        .catch(err => res.status(400).json({ error: err }));

    res.send(data);
});