<template>
    <div>
        <PageTitle title='About KeepUp'/>
    </div>
</template>

<script>

import PageTitle from '@/components/PageTitle.vue'

export default {
    name: 'Market',
    components: {
        PageTitle
    }
}

</script>